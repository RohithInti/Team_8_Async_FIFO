var g_db_data = {"7":1,"6":1,"3":1,"1":1,"2":1,"5":1,"4":1};
processScopesDbFile(g_db_data);