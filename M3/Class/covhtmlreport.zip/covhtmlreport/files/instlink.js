var g_data = {"8":[7,"vif",1],"9":[7,"dut",1],"7":[-1,"testbench_top",1],"10":[-1,"tb_pkg",1],"11":[-1,"coverage_pkg",1],"28":[-1,"top_sv_unit",1]};
processInstLinks(g_data);